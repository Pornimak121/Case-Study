package com.example.login_sample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Second_Screen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second__screen)






    }
}