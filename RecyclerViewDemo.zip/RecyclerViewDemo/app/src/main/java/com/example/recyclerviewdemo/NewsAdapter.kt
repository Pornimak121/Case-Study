package com.example.recyclerviewdemo

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item_layout.view.*
import java.security.AccessControlContext

class NewsAdapter(val context: Context, val articles: List<Article>) :
    RecyclerView.Adapter<NewsAdapter.Artcileviewholder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Artcileviewholder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false)
        return Artcileviewholder(view)
    }

    override fun getItemCount(): Int {
        return articles.size
    }

    override fun onBindViewHolder(holder: Artcileviewholder, position: Int) {
        val article = articles[position]
        holder.newstitle.text = article.title
        holder.newsdesc.text = article.description
        Glide.with(context).load(article.urlToImage).into(holder.newsimage)

        val intent = Intent(context,DetailsPage::class.java)

        holder.itemView.setOnClickListener {
            intent.putExtra("URL",article.url)
            context.startActivity(intent)
        }
        
    }

    class Artcileviewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var newsimage = itemView.findViewById<ImageView>(R.id.NewsImage)
        var newstitle = itemView.findViewById<TextView>(R.id.NewsTitle)
        var newsdesc = itemView.findViewById<TextView>(R.id.NewsDesc)


    }
}