package com.example.recyclerviewdemo

data class  News(val totalResults: Int,val articles: List<Article>)