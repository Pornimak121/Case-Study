 package com.example.currencyconverter

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_second.*
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import org.json.JSONObject as JSONObject1


 class second: AppCompatActivity()
 {

     override fun onCreate(savedInstanceState: Bundle?)
     {
         super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_second)
         val makeCall = RetrofitClient.mycall
         makeCall.clone().enqueue(object : Callback<UserResponse>
         {

             override fun onFailure(call: Call<UserResponse>, t: Throwable)
             {
                 Log.e("mytag", "error is" + t)
             }

             override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>)
             {
                 textView2.text = response.body()!!.getRates().getiNR().toString()
                 buttonConvert.setOnClickListener {

                     var usd = editTextNumbervalue.text.toString().toInt()
                        var sample : Float = (textView2.text as String).toFloat()
                     var inr : Float = usd.times(sample)
                     var res: String = inr.toString()
                     if (usd == null ){
                        // Toast.makeText(this,"plz enter appropriate value",Toast.LENGTH_LONG).show()
                     }
                     else{
                         editTextNumber3.setText(res).toString()
                     }






                 //print(response.body().toString())
             }

         }

         });

 }
 }




