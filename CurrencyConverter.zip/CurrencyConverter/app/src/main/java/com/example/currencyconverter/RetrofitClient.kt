package com.example.currencyconverter

import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.POST


//https://api.exchangeratesapi.io/latest?base=USD&symbols=INR

class RetrofitClient {

    interface APIInterface
    {
        @GET(
            "/latest?base=USD&symbols=INR"

        )

        fun getUsers(): Call<UserResponse>


    }


        companion object
        {

            val myRetrofitClient = Retrofit.Builder()
                //.baseUrl("https://jsonplaceholder.typicode.com/")
               .baseUrl("https://api.exchangeratesapi.io/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            val myapiinterface = myRetrofitClient.create(APIInterface::class.java)
            val mycall : Call<UserResponse> = myapiinterface.getUsers()

        }




}